package fullstack.oblig2.oblig2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakeApplicationTests {

	@Test
	void contextLoads() {
	}

}
